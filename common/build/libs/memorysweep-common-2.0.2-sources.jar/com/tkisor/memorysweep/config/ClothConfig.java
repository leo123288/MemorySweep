package com.tkisor.memorysweep.config;

import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import me.shedaniel.clothconfig2.gui.entries.BooleanListEntry;
import me.shedaniel.clothconfig2.gui.entries.IntegerListEntry;
import net.minecraft.class_2561;
import net.minecraft.class_437;

public class ClothConfig {
    private class_437 parent;

    private ClothConfig(class_437 parent) {
        this.parent = parent;
    }

    public static class_437 create(class_437 parent) {
        return new ClothConfig(parent).builder();
    }

    private class_437 builder() {
        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(class_2561.method_43471("text.memorysweep.title"));

        ConfigEntryBuilder entryBuilder = builder.entryBuilder();
        ModConfig config = ModConfig.get();

        ConfigCategory category = builder.getOrCreateCategory(class_2561.method_43471("text.memorysweep.category.config"));

        BooleanListEntry b1 = entryBuilder.startBooleanToggle(class_2561.method_43471("text.memorysweep.memorysweep"), config.memorySweep)
                .setDefaultValue(true)
                .setTooltip(class_2561.method_43471("text.memorysweep.desc.memorysweep"))
                .setSaveConsumer(save -> config.memorySweep = save)
                .build();
        IntegerListEntry b2 = entryBuilder.startIntField(class_2561.method_43471("text.memorysweep.sweep_interval"), config.sweepInterval)
                .setDefaultValue(900)
                .setMin(0)
                .setMax(Integer.MAX_VALUE)
                .setTooltip(class_2561.method_43471("text.memorysweep.desc.sweep_interval"))
                .setSaveConsumer(save -> config.sweepInterval = save)
                .build();
        IntegerListEntry b3 = entryBuilder.startIntField(class_2561.method_43471("text.memorysweep.min_memory_usage"), config.minMemoryUsage)
                .setDefaultValue(75)
                .setMin(0)
                .setMax(100)
                .setTooltip(class_2561.method_43471("text.memorysweep.desc.min_memory_usage"))
                .setSaveConsumer(save -> config.minMemoryUsage = save)
                .build();
        BooleanListEntry b4 = entryBuilder.startBooleanToggle(class_2561.method_43471("text.memorysweep.silent"), config.silent)
                .setDefaultValue(false)
                .setTooltip(class_2561.method_43471("text.memorysweep.desc.silent"))
                .setSaveConsumer(save -> config.silent = save)
                .build();
        category.addEntry(b1);
        category.addEntry(b2);
        category.addEntry(b3);
        category.addEntry(b4);

        builder.setSavingRunnable(ModConfig::write);
        return builder.build();
    }
}
