package com.tkisor.memorysweep;

import com.tkisor.memorysweep.config.ModConfig;
import com.tkisor.memorysweep.data.Flags;
import com.tkisor.memorysweep.utils.SweepUtil;
import dev.architectury.event.CompoundEventResult;
import dev.architectury.event.events.client.ClientChatEvent;
import dev.architectury.event.events.client.ClientPlayerEvent;
import dev.architectury.event.events.client.ClientTickEvent;
import dev.architectury.event.events.common.CommandRegistrationEvent;
import dev.architectury.platform.Platform;
import dev.architectury.utils.Env;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;
import net.minecraft.class_156;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class MemorySweep {
    public static final String MOD_ID = "memorysweep";
    public static final Logger logger = LoggerFactory.getLogger(MOD_ID);

    public static class_746 player = null;

    public static void init() {
        // Write common init code here.
        if (!Flags.initConfig) {
            ModConfig.init(Platform.getGameFolder());
            Flags.initConfig = true;
        }


        if (ModConfig.isLoaderConfigMod() && Platform.getEnvironment() == Env.CLIENT) {
            Platform.getMod(MOD_ID).registerConfigurationScreen(parent -> ModConfig.get().getConfigScreen(parent));
        }

        CommandRegistrationEvent.EVENT.register((dispatcher, registry, selection) -> {
            dispatcher.register(class_2170.method_9247("memorysweep")
                    .then(class_2170.method_9247("client")
                            .executes(context -> {
                                if (Platform.getEnvironment() == Env.SERVER) {
                                    context.getSource().method_45068(class_2561.method_43471("memorysweep.gc.use_chat"));
                                } else {
                                    Flags.sweepClient = true;
                                }

                                return 0;
                            })
                    )
                    .then(class_2170.method_9247("server")
                            .requires(source -> {
                                int requiredPermission = Platform.getEnvironment() == Env.CLIENT ? 0 : 2;
                                return source.method_9259(requiredPermission);
                            })
                            .executes(context -> {
                                class_156.method_27958().submit(() -> {
                                    try {
                                        Optional.ofNullable(context.getSource().method_44023())
                                                .ifPresent(player -> player.method_7353(class_2561.method_43469("memorysweep.gc.start", (SweepUtil.getMemoryInGB())), true));

                                        System.gc();
                                        Thread.sleep(1000L);
                                        System.gc();

                                        context.getSource().method_44023().method_7353(class_2561.method_43469("memorysweep.gc.end", (SweepUtil.getMemoryInGB())), true);

                                        logger.info("MemorySweep: Garbage Collection executed.");
                                    } catch (InterruptedException e) {
                                        Thread.currentThread().interrupt();
                                    }
                                });
                                return 0;
                            })
                    )

            );
        });

        if (Platform.getEnvironment() == Env.CLIENT) {
            ClientChatEvent.RECEIVED.register((type, message) -> {
                if (class_310.method_1551().field_1724 != null) {
                    class_746 player1 = class_310.method_1551().field_1724;
                    if (type.comp_920().getString().equals(player1.method_5477().getString())) {
                        if (message.getString().contains("memorysweep")) {
                            Flags.sweepClient = true;
                        }
                    }
                }

                return CompoundEventResult.pass();
            });

            ClientPlayerEvent.CLIENT_PLAYER_JOIN.register(player1 -> player = player1);
            ClientPlayerEvent.CLIENT_PLAYER_QUIT.register(player1 -> player = null);

            ClientTickEvent.CLIENT_PRE.register(clientLevel -> {
                if (!ModConfig.get().memorySweep) return;

                if (SweepUtil.isSweep()) {
                    if (player != null && !ModConfig.get().silent) {
                        player.method_7353(class_2561.method_43469("memorysweep.gc.start", (SweepUtil.getMemoryInGB())), true);
                    }
                    SweepUtil.sweepAsync().thenAccept(data -> {
                        if (player != null && !ModConfig.get().silent) {
                            player.method_7353(class_2561.method_43469("memorysweep.gc.end", ((long) (data.getRight() / 1024.0 / 1024.0 / 1024.0))), true);
                        }
                    });
                }

                if (SweepUtil.isAvgSweep()) {
                    SweepUtil.calculateAndSweepMemory().thenAccept(data -> {
                        if (player != null && !ModConfig.get().silent) {
                            player.method_7353(class_2561.method_43469("memorysweep.gc.end", (SweepUtil.getMemoryInGB())), true);
                        }
                    });
                }
            });
        }
    }
}
