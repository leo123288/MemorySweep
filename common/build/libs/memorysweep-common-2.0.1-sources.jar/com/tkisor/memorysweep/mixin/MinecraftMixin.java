package com.tkisor.memorysweep.mixin;

import com.tkisor.memorysweep.MemorySweep;
import com.tkisor.memorysweep.config.ModConfig;
import com.tkisor.memorysweep.data.Flags;
import com.tkisor.memorysweep.utils.SweepUtil;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftMixin {
    @Inject(method = "run", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;runTick(Z)V"))
    private void memorysweep(CallbackInfo ci) {
        if (!Flags.isClient) Flags.isClient = true;
        if (!Flags.initConfig) {
            ModConfig.init(class_310.method_1551().field_1697.toPath());
            Flags.initConfig = true;
        }

        if (Flags.sweepClient) {
            Flags.sweepClient = false;

            Thread sweepThread = new Thread(() -> {
                try {
                    long before = SweepUtil.getUsedMemory();
                    if (MemorySweep.player != null && !ModConfig.get().silent) {
                        MemorySweep.player.method_7353(class_2561.method_43469("memorysweep.gc.start", (SweepUtil.getMemoryInGB())), true);
                    }

                    System.gc();
                    Thread.sleep(100);
                    long after = SweepUtil.getUsedMemory();
                    if (MemorySweep.player != null && !ModConfig.get().silent) {
                        MemorySweep.player.method_7353(class_2561.method_43469("memorysweep.gc.end", (SweepUtil.getMemoryInGB())), true);
                    }
                    MemorySweep.logger.info("MemorySweep: GC executed. Before: {}MB, After: {}MB",
                            before / (1024 * 1024), after / (1024 * 1024));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    MemorySweep.logger.warn("Memory sweep interrupted.", e);
                }
            });

            sweepThread.setDaemon(true);
            sweepThread.setName("MemorySweep-Thread");
            sweepThread.start();

        }
    }
}
